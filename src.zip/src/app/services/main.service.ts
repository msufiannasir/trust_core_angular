import { Injectable } from '@angular/core';
import { CollectionsService } from './collections.service';
// import { UsersService } from './users.service';

@Injectable({
  providedIn: 'root',
})
export class MainService {
  constructor(
    // public insuranceCompaniesService: InsuranceCompaniesService,
    // public usersService: UsersService
  ) {}

  // Add shared methods if needed
}
