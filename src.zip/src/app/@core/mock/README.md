Application-wise data providers.
